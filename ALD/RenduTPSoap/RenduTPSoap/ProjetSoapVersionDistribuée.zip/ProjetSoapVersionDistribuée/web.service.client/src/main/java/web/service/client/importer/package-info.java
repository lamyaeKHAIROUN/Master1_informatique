@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.example.com/")
package web.service.client.importer;
